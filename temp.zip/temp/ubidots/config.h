#ifndef CONFIG_H
#define CONFIG_H

const char* ssid = "voidMatrix[Sahil's A35]";
const char* password = "voidMatrix@15112002.getIt()";

const char* UBIDOTS_TOKEN = "BBUS-vdCXddqR9odv3IAb7YKgOFZJWN1BPL";  
const char* DEVICE_LABEL = "Temperature";          
const char* UBIDOTS_URL = "https://industrial.api.ubidots.com/api/v1.6/devices/Temperature/";

#endif